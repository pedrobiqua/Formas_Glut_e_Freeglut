#pragma once
class Casa3d
{
public:
	float xc, yc, zc, aac;
	float xt, yt, zt, aat;
	void Desenha(int Um);
	void Desenha();
	Casa3d(float xcc, float ycc, float zcc, float acc, float xtt, float ytt, float ztt, float att);
};

